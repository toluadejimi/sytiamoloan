## The Library directory is deprecated.

The files in this directory are only still in place to provide backward compatibility with Requests 1.x.
Please see the release notes of Requests 2.0.0 on how to upgrade.

This directory will be removed in Requests v 4.0.0.
