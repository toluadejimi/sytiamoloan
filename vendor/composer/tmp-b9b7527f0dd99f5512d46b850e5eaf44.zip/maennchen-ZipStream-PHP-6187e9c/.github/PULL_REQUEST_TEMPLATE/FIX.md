<!---
name: 🐞 Bug Fix
about: You have a fix for a bug?
labels: bug
--->

<!--
- Please do not send a pull request for an issue in a version of ZipStream-PHP
  that is no longer supported.
  See: https://github.com/maennchen/ZipStream-PHP#version-support
- Please target the oldest branch of ZipStream-PHP that is still supported and
  affected by this bug.
-->
