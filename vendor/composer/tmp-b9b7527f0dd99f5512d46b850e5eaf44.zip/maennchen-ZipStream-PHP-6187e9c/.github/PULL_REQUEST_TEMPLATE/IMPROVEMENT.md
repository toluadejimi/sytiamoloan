<!---
name: ⚙ Improvement
about: You have some improvement to make ZipStream-PHP better?
labels: enhancement
--->

<!--
- Please target the `main` branch of ZipStream-PHP.
-->
